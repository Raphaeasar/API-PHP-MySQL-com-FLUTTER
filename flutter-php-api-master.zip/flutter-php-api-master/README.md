# flutter-php-api
Uma api simples feita para conexão com o flutter
