<?php
return array(
  'adapter' => 'mysql',
  'host' => '192.168.15.36',
  'dbname' => 'test',
  'username' => 'youtube',
  'password' => '142536',
);

