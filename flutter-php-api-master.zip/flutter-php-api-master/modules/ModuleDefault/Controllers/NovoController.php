<?php
namespace ModuleDefault\Controllers;

class NovoController extends AbstractController
{
  public function indexAction() {
    // Here is where the legends begins...
  }
}

